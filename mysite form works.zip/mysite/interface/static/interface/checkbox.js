[].forEach.call( document.querySelectorAll('.hide-checkbox'), 
	function(element) {
		element.style.display = 'none';
	});

