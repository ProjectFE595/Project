from django.apps import AppConfig


class InterfaceConfig(AppConfig):
    name = 'interface'

# we need to add a reference to its configuration class in the INSTALLED_APPS setting.
# The PollsConfig class is in the appName/apps.py file, so its dotted path is 'appName.apps.AppNameConfig'.
# Edit the mysite/settings.py file and add that dotted path to the INSTALLED_APPS setting.
