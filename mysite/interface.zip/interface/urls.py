from django.conf.urls import url

from . import views

app_name = 'interface'
# add namespaces to your URLconf. In the interface/urls.py file,
# go ahead and add an app_name to set the application namespace:

urlpatterns = [
    # url(r'^interface/', interface.view.Hello, name='Hello'),
]