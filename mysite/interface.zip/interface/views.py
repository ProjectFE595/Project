from django.shortcuts import render, get_object_or_404
# To call the view, we need to map it to a URL - and for this we need a URLconf.
# Create your views here.
from django.http import HttpResponseRedirect, HttpResponse
from .models import Choice, Question
#from django.template import loader
from django.urls import reverse
from django.views import generic




def Hello(request):

    return render(request, 'interface/index.html', {'error_message': "You didn't select a choice."})

